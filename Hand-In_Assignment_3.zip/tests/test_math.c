/** @file test_math.c
 *  @brief Independent mathematical integration tests for cache behavior validation.
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "../src/memory.h"

/* ANSI Color Codes for terminal formatting */
#define C_RESET  "\x1b[0m"
#define C_GREEN  "\x1b[32m"
#define C_RED    "\x1b[31m"
#define C_BOLD   "\x1b[1m"
#define C_CYAN   "\x1b[36m"

#define CHECK_STATS(test_name, cache, exp_hits, exp_misses) do { \
    printf(C_CYAN C_BOLD "\n[ TEST ] %s\n" C_RESET, test_name); \
    printf("  ├─ Hits   | Expected: %-6lu | Obtained: %-6lu\n", (uint64_t)(exp_hits), (cache).hits); \
    printf("  ├─ Misses | Expected: %-6lu | Obtained: %-6lu\n", (uint64_t)(exp_misses), (cache).misses); \
    if ((cache).hits != (exp_hits) || (cache).misses != (exp_misses)) { \
        printf(C_RED C_BOLD "  └─ [FAIL] Cache logic error detected!\n\n" C_RESET); \
        exit(EXIT_FAILURE); \
    } else { \
        printf(C_GREEN C_BOLD "  └─ [PASS] Values match theory.\n\n" C_RESET); \
    } \
} while(0)

int main() {
    printf(C_BOLD "\n=== INDEPENDENT CACHE LOGIC VALIDATION ===\n" C_RESET);
    
    /* ---------------------------------------------------------
     * TEST 1: Strict Spatial Locality (Compulsory Misses)
     * --------------------------------------------------------- */
    memory_init_dynamic(32768, 4, 32768, 8, 524288, 8, 64, 0, 0);
    
    for (int i = 0; i < 8; i++) {
        memory_read((double*)(uintptr_t)(i * 8), NULL);
    }
    CHECK_STATS("Read a full cache line (8 contiguous doubles)", L1D, 7, 1);
    
    memory_finish();

    /* ---------------------------------------------------------
     * TEST 2: Associativity Conflict (Conflict Misses)
     * --------------------------------------------------------- */
    memory_init_dynamic(32768, 4, 32768, 8, 524288, 8, 64, 0, 0);
    
    for (int i = 0; i < 9; i++) {
        memory_read((double*)(uintptr_t)(i * 4096), NULL);
    }
    CHECK_STATS("Associativity conflict (9 blocks on an 8-way cache)", L1D, 0, 9);
    
    memory_finish();
    
    /* ---------------------------------------------------------
     * TEST 3: LRU Replacement Policy Verification
     * --------------------------------------------------------- */
    memory_init_dynamic(32768, 4, 32768, 8, 524288, 8, 64, 0, 0);
    
    for (int i = 0; i < 9; i++) {
        memory_read((double*)(uintptr_t)(i * 4096), NULL);
    }
    
    /* Re-reading the very first address which should have been evicted by the 9th access */
    memory_read((double*)(uintptr_t)(0), NULL);
    
    CHECK_STATS("Verification of the LRU eviction policy", L1D, 0, 10);
    
    memory_finish();
    
    printf(C_GREEN C_BOLD "=== All logical tests passed successfully! ===\n\n" C_RESET);
    
    return EXIT_SUCCESS;
}