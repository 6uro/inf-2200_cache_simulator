/** @file memory.h
 *  @brief Cache definitions, data structures, and public API.
 */

#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>
#include <stdbool.h>

/* -------------------------------------------------------------------------- */
/* Enums for Cache Policies                                                   */
/* -------------------------------------------------------------------------- */

typedef enum {
    REPL_LRU = 0,
    REPL_RANDOM = 1
} repl_policy_t;

typedef enum {
    WRITE_BACK = 0,
    WRITE_THROUGH = 1
} write_policy_t;

/* -------------------------------------------------------------------------- */
/* Cache Data Structures                                                      */
/* -------------------------------------------------------------------------- */

/**
 * @brief Represents a single cache line (block).
 */
typedef struct {
    bool valid;
    bool dirty;
    uint64_t tag;
    uint64_t timestamp; /* Used for LRU policy */
} cache_line_t;

/**
 * @brief Represents a cache level (L1I, L1D, L2).
 */
typedef struct {
    uint32_t line_size;
    uint32_t assoc;
    uint32_t sets;
    
    uint64_t hits;
    uint64_t misses;
    uint64_t writes;
    
    cache_line_t* lines; /* Array of cache lines */
} cache_t;

/* -------------------------------------------------------------------------- */
/* Global Cache Instances                                                     */
/* -------------------------------------------------------------------------- */

extern cache_t L1I;
extern cache_t L1D;
extern cache_t L2;

/* -------------------------------------------------------------------------- */
/* Public API Functions                                                       */
/* -------------------------------------------------------------------------- */

void memory_init_dynamic(uint32_t l1i_size, uint32_t l1i_assoc,
                         uint32_t l1d_size, uint32_t l1d_assoc,
                         uint32_t l2_size, uint32_t l2_assoc,
                         uint32_t line_size,
                         repl_policy_t repl_policy, write_policy_t write_policy);

void memory_fetch(uint32_t *instruction_num, uint32_t *instruction_val);
void memory_read(double *address, double *value);
void memory_write(double *address, double *value);
void memory_finish(void);

#endif /* MEMORY_H */