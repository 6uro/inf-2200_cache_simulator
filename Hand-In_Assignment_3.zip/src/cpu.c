/** @file cpu.c
 *  @brief Simulates a system with caching between the CPU and the main memory.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "memory.h"

/** @brief Size of the square matrices (N x N). */
#define N 256

/** 
 * @brief Enumeration of available execution modes.
 */
typedef enum {
    NAIVE = 0,  /**< Naive matrix multiplication */
    BLOCK = 1,  /**< Cache-optimized block matrix multiplication */
    TRACE = 3   /**< Mode to generate memory trace for Dinero IV */
} benchmark_t;

/**
 * @brief Performs a naive matrix multiplication (O(N^3)).
 * 
 * @param a Pointer to the first input matrix (A).
 * @param b Pointer to the second input matrix (B).
 * @param c Pointer to the output matrix (C).
 * @param instruction_num Pointer used to simulate instruction fetching addresses.
 */
void naive_mat_mul(double* a, double* b, double* c, uint32_t* instruction_num) {
    memory_fetch(instruction_num, NULL);
    for(int i = 0; i < N; i++) {
        memory_fetch(instruction_num+1, NULL);
        for(int j = 0; j < N; j++) {
            memory_fetch(instruction_num+2, NULL);
            for(int k = 0; k < N; k++) {
                memory_fetch(instruction_num+3, NULL);
                memory_read(a + N*i + k, NULL);
                memory_fetch(instruction_num+4, NULL);
                memory_read(b + N*k + j, NULL);
                memory_fetch(instruction_num+5, NULL);
                memory_read(c + N*i + j, NULL);
                memory_fetch(instruction_num+6, NULL);
                memory_write(c + N*i + j, NULL);
                memory_fetch(instruction_num+7, NULL);
            }
        }
    }
}

/**
 * @brief Performs a cache-optimized block matrix multiplication.
 * 
 * @param a Pointer to the first input matrix (A).
 * @param b Pointer to the second input matrix (B).
 * @param c Pointer to the output matrix (C).
 * @param instruction_num Pointer used to simulate instruction fetching addresses.
 * @param SM The sub-matrix (block) size computed based on the cache line size.
 */
void block_mat_mul(double* a, double* b, double* c, uint32_t* instruction_num, int SM) {
    int i, j, k, i2, k2, j2;
    double *rres, *rmul1, *rmul2;
    
    memory_fetch(instruction_num, NULL);
    for (i = 0; i < N; i += SM) {
        memory_fetch(instruction_num+1, NULL);
        for (j = 0; j < N; j += SM) {
            memory_fetch(instruction_num+2, NULL);
            for (k = 0; k < N; k += SM) {
                memory_fetch(instruction_num+3, NULL);
                for (i2 = 0, rres = &c[i*N+j], rmul1 = &a[i*N+k]; i2 < SM; ++i2, rres += N, rmul1 += N) {
                    memory_fetch(instruction_num+4, NULL);
                    for (k2 = 0, rmul2 = &b[k*N+j]; k2 < SM; ++k2, rmul2 += N) {
                        memory_fetch(instruction_num+5, NULL);
                        for (j2 = 0; j2 < SM; ++j2) {
                            memory_fetch(instruction_num+6, NULL);
                            memory_read(rmul1+k2, NULL);
                            memory_fetch(instruction_num+7, NULL);
                            memory_read(rmul2+j2, NULL);
                            memory_fetch(instruction_num+8, NULL);
                            memory_read(rres+j2, NULL);
                            memory_fetch(instruction_num+9, NULL);
                            memory_write(rres+j2, NULL);
                            memory_fetch(instruction_num+10, NULL);
                        }
                    }
                }
            }
        }
    }
}

/**
 * @brief Main entry point for the CPU and cache simulator.
 * 
 * @param argc Number of command line arguments.
 * @param argv Array of command line arguments.
 * @return Exit status (0 on success).
 */
int main(int argc, char *argv[])
{
    extern bool generate_trace;

    int bench_type = NAIVE; 
    uint32_t line_size = 64;
    uint32_t l1d_size = 32768, l1d_assoc = 8;
    uint32_t l2_size = 524288, l2_assoc = 8;
    int repl_policy = 0;  /* 0 = LRU, 1 = RANDOM */
    int write_policy = 0; /* 0 = WRITE_BACK, 1 = WRITE_THROUGH */

    /* Parse command-line arguments to override default parameters */
    if (argc >= 2) bench_type = atoi(argv[1]);
    if (argc >= 3) line_size = atoi(argv[2]);
    if (argc >= 4) l1d_size = atoi(argv[3]);
    if (argc >= 5) l1d_assoc = atoi(argv[4]);
    if (argc >= 6) l2_size = atoi(argv[5]);
    if (argc >= 7) l2_assoc = atoi(argv[6]);
    if (argc >= 8) repl_policy = atoi(argv[7]);
    if (argc >= 9) write_policy = atoi(argv[8]);

    memory_init_dynamic(32768, 4, l1d_size, l1d_assoc, l2_size, l2_assoc, line_size, 
                        (repl_policy_t)repl_policy, (write_policy_t)write_policy);


    /* 
     * BYPASS ASLR: Assigning hardcoded absolute addresses instead of using malloc().
     * Since the pointers are never explicitly dereferenced for floating-point 
     * calculations in this simulation, this prevents Address Space Layout 
     * Randomization (ASLR) from skewing the cache miss comparisons.
     */
    
    double* a = (double*)0x10000000ULL;
    double* b = (double*)0x20000000ULL;
    double* c = (double*)0x30000000ULL;
    uint32_t* instruction_num = (uint32_t*)0x40000000ULL;

    /* Use of malloc() for the experimental setup
    double* a = (double*)malloc(N * N * sizeof(double));
    double* b = (double*)malloc(N * N * sizeof(double));
    double* c = (double*)malloc(N * N * sizeof(double));
    uint32_t* instruction_num = (uint32_t*)malloc(100 * sizeof(uint32_t));
    */

    if (bench_type == TRACE) {
        generate_trace = true;
        int SM = line_size / sizeof(double);
        block_mat_mul(a, b, c, instruction_num, SM);
        return 0; /* Early exit for trace generation */
    }

    if (bench_type == NAIVE) {
        printf("Running NAIVE (Line size: %d, L1D size: %d, L1D assoc: %d)...\n", line_size, l1d_size, l1d_assoc);
        naive_mat_mul(a, b, c, instruction_num);
    } else if (bench_type == BLOCK) {
        int SM = line_size / sizeof(double);
        printf("Running BLOCK (Line size: %d, SM: %d)...\n", line_size, SM);
        block_mat_mul(a, b, c, instruction_num, SM);
    } 
    
    memory_finish();
    /* Use free() if malloc() is used (Experimental setup)
    free(a); free(b); free(c); free(instruction_num);
    */
    
    return 0;
}