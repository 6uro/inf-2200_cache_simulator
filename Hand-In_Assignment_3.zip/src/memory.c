/** @file memory.c
 *  @brief Implementation of the CPU cache hierarchy (L1I, L1D, L2) 
 *         with dynamic parameters, replacement, and write policies.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "memory.h"

/* -------------------------------------------------------------------------- */
/* Global Variables & Cache Structures                                        */
/* -------------------------------------------------------------------------- */

cache_t L1I;
cache_t L1D;
cache_t L2;

/* Used by cpu.c to toggle trace generation for Dinero IV */
bool generate_trace = false;

static repl_policy_t  current_repl  = REPL_LRU;
static write_policy_t current_write = WRITE_BACK;
static uint64_t       global_timestamp = 0;

/* -------------------------------------------------------------------------- */
/* Internal Helper Functions                                                  */
/* -------------------------------------------------------------------------- */

/**
 * @brief Computes the tag and index for a given address and cache configuration.
 */
static void decode_address(const cache_t* cache, uint64_t addr, uint64_t* tag, uint32_t* index) {
    uint32_t offset_bits = 0;
    uint32_t temp = cache->line_size;
    while (temp >>= 1) offset_bits++;

    uint32_t index_bits = 0;
    temp = cache->sets;
    while (temp >>= 1) index_bits++;

    *index = (addr >> offset_bits) & ((1 << index_bits) - 1);
    *tag = addr >> (offset_bits + index_bits);
}

/**
 * @brief Reconstructs the full 64-bit physical address from a cache tag and index.
 */
static uint64_t reconstruct_address(const cache_t* cache, uint64_t tag, uint32_t index) {
    uint32_t offset_bits = 0;
    uint32_t temp = cache->line_size;
    while (temp >>= 1) offset_bits++;

    uint32_t index_bits = 0;
    temp = cache->sets;
    while (temp >>= 1) index_bits++;

    return (tag << (offset_bits + index_bits)) | ((uint64_t)index << offset_bits);
}

/**
 * @brief Invalidates a specific address in a cache (used for L2 strict inclusion).
 */
static void invalidate_cache_line(cache_t* cache, uint64_t addr) {
    if (addr == 0) return;
    
    uint64_t tag;
    uint32_t index;
    decode_address(cache, addr, &tag, &index);

    for (uint32_t w = 0; w < cache->assoc; w++) {
        cache_line_t* line = &cache->lines[index * cache->assoc + w];
        if (line->valid && line->tag == tag) {
            line->valid = false;
            line->dirty = false;
            return; 
        }
    }
}

/**
 * @brief Enforces strict inclusion: back-invalidates L1 if L2 evicts a block.
 */
static void handle_l2_eviction(uint64_t l2_ev_addr) {
    if (l2_ev_addr != 0) {
        invalidate_cache_line(&L1I, l2_ev_addr);
        invalidate_cache_line(&L1D, l2_ev_addr);
    }
}

/**
 * @brief Core function to access a specific cache (Read or Write).
 * 
 * @return true if HIT, false if MISS.
 */
static bool access_cache(cache_t* cache, uint64_t addr, bool is_write, 
                         uint64_t* ev_addr, bool* ev_dirty) 
{
    uint64_t tag;
    uint32_t index;
    decode_address(cache, addr, &tag, &index);
    
    global_timestamp++;

    /* 1. Search for a HIT */
    for (uint32_t w = 0; w < cache->assoc; w++) {
        cache_line_t* line = &cache->lines[index * cache->assoc + w];
        if (line->valid && line->tag == tag) {
            cache->hits++;
            line->timestamp = global_timestamp;
            /* In Write-Through, L1 lines are never marked dirty */
            if (is_write && current_write == WRITE_BACK) {
                line->dirty = true;
            }
            return true; 
        }
    }

    /* 2. It's a MISS */
    cache->misses++;
    int victim_way = -1;

    /* Look for an invalid line first */
    for (uint32_t w = 0; w < cache->assoc; w++) {
        if (!cache->lines[index * cache->assoc + w].valid) {
            victim_way = w;
            break;
        }
    }

    /* If the set is full, apply the Replacement Policy */
    if (victim_way == -1) {
        if (current_repl == REPL_RANDOM) {
            victim_way = rand() % cache->assoc;
        } else {
            uint64_t min_timestamp = UINT64_MAX;
            for (uint32_t w = 0; w < cache->assoc; w++) {
                if (cache->lines[index * cache->assoc + w].timestamp < min_timestamp) {
                    min_timestamp = cache->lines[index * cache->assoc + w].timestamp;
                    victim_way = w;
                }
            }
        }
    }

    /* Extract victim info for potential Write-Back or Back-Invalidation */
    cache_line_t* victim = &cache->lines[index * cache->assoc + victim_way];
    if (victim->valid) {
        if (ev_addr)  *ev_addr  = reconstruct_address(cache, victim->tag, index);
        if (ev_dirty) *ev_dirty = victim->dirty;
    } else {
        if (ev_addr)  *ev_addr  = 0;
        if (ev_dirty) *ev_dirty = false;
    }

    /* Load the new block */
    victim->valid = true;
    victim->tag = tag;
    victim->timestamp = global_timestamp;
    victim->dirty = (is_write && current_write == WRITE_BACK) ? true : false;

    return false;
}

/* -------------------------------------------------------------------------- */
/* Public API                                                                 */
/* -------------------------------------------------------------------------- */

void memory_init_dynamic(uint32_t l1i_size, uint32_t l1i_assoc,
                         uint32_t l1d_size, uint32_t l1d_assoc,
                         uint32_t l2_size, uint32_t l2_assoc,
                         uint32_t line_size,
                         repl_policy_t repl_policy, write_policy_t write_policy) 
{
    current_repl = repl_policy;
    current_write = write_policy;

    if (current_repl == REPL_RANDOM) {
        srand(42);
    }

    L1I.line_size = line_size;
    L1I.assoc = l1i_assoc;
    L1I.sets = l1i_size / (line_size * l1i_assoc);
    L1I.lines = (cache_line_t*)calloc(L1I.sets * L1I.assoc, sizeof(cache_line_t));
    L1I.hits = 0; L1I.misses = 0; L1I.writes = 0;

    L1D.line_size = line_size;
    L1D.assoc = l1d_assoc;
    L1D.sets = l1d_size / (line_size * l1d_assoc);
    L1D.lines = (cache_line_t*)calloc(L1D.sets * L1D.assoc, sizeof(cache_line_t));
    L1D.hits = 0; L1D.misses = 0; L1D.writes = 0;

    L2.line_size = line_size;
    L2.assoc = l2_assoc;
    L2.sets = l2_size / (line_size * l2_assoc);
    L2.lines = (cache_line_t*)calloc(L2.sets * L2.assoc, sizeof(cache_line_t));
    L2.hits = 0; L2.misses = 0; L2.writes = 0;
}

void memory_fetch(uint32_t *instruction_num, uint32_t *instruction_val) {
    uint64_t addr = (uint64_t)(uintptr_t)instruction_num;
    
    if (generate_trace) {
        printf("2 %lx\n", addr);
    }

    uint64_t l1_ev_addr = 0;
    bool l1_ev_dirty = false;

    if (!access_cache(&L1I, addr, false, &l1_ev_addr, &l1_ev_dirty)) {
        uint64_t l2_ev_addr = 0;
        bool l2_ev_dirty = false;
        if (!access_cache(&L2, addr, false, &l2_ev_addr, &l2_ev_dirty)) {
            handle_l2_eviction(l2_ev_addr);
        }
    }
}

void memory_read(double *address, double *value) {
    uint64_t addr = (uint64_t)(uintptr_t)address;
    
    if (generate_trace) {
        printf("0 %lx\n", addr);
    }

    uint64_t l1_ev_addr = 0;
    bool l1_ev_dirty = false;

    if (!access_cache(&L1D, addr, false, &l1_ev_addr, &l1_ev_dirty)) {
        uint64_t l2_ev_addr = 0;
        bool l2_ev_dirty = false;
        if (!access_cache(&L2, addr, false, &l2_ev_addr, &l2_ev_dirty)) {
            handle_l2_eviction(l2_ev_addr);
        }

        if (l1_ev_dirty) {
            L1D.writes++;
            uint64_t l2_wb_addr = 0;
            bool l2_wb_dirty = false;
            if (!access_cache(&L2, l1_ev_addr, true, &l2_wb_addr, &l2_wb_dirty)) {
                handle_l2_eviction(l2_wb_addr);
            }
        }
    }
}

void memory_write(double *address, double *value) {
    uint64_t addr = (uint64_t)(uintptr_t)address;
    
    if (generate_trace) {
        printf("1 %lx\n", addr);
    }

    uint64_t l1_ev_addr = 0;
    bool l1_ev_dirty = false;

    if (!access_cache(&L1D, addr, true, &l1_ev_addr, &l1_ev_dirty)) {
        uint64_t l2_ev_addr = 0;
        bool l2_ev_dirty = false;
        if (!access_cache(&L2, addr, false, &l2_ev_addr, &l2_ev_dirty)) {
            handle_l2_eviction(l2_ev_addr);
        }

        if (l1_ev_dirty) {
            L1D.writes++;
            uint64_t l2_wb_addr = 0;
            bool l2_wb_dirty = false;
            if (!access_cache(&L2, l1_ev_addr, true, &l2_wb_addr, &l2_wb_dirty)) {
                handle_l2_eviction(l2_wb_addr);
            }
        }
    }

    if (current_write == WRITE_THROUGH) {
        L1D.writes++;
        uint64_t l2_ev_addr = 0;
        bool l2_ev_dirty = false;
        if (!access_cache(&L2, addr, true, &l2_ev_addr, &l2_ev_dirty)) {
            handle_l2_eviction(l2_ev_addr);
        }
        L2.writes++;
    }
}

void memory_finish(void) {
    printf("\n");
    printf("L1I - Hits: %lu, Misses: %lu, Writes: %lu\n", L1I.hits, L1I.misses, L1I.writes);
    printf("L1D - Hits: %lu, Misses: %lu, Writes: %lu\n", L1D.hits, L1D.misses, L1D.writes);
    printf("L2  - Hits: %lu, Misses: %lu, Writes: %lu\n", L2.hits, L2.misses, L2.writes);

    if (L1I.lines) free(L1I.lines);
    if (L1D.lines) free(L1D.lines);
    if (L2.lines)  free(L2.lines);
}