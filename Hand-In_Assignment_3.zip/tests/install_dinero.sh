#!/bin/bash

cd "$(dirname "$0")" || exit 1

echo "=== Downloading Dinero IV from GitHub ==="
git clone https://github.com/atos-tools/dineroIV

echo "=== Compiling Dinero IV ==="
cd dineroIV
./configure
make

echo "=== Dinero IV successfully installed! ==="