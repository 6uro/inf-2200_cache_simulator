#!/bin/bash

# Directories relative to the src/ folder (where the make command is executed)
OUTDIR="../tests"
DINERO="../tests/dineroIV/dineroIV"

echo "=== Generating memory trace (Please wait...) ==="
./cachesim 3 > $OUTDIR/trace.txt

echo "=== Executing Dinero IV ==="
$DINERO \
    -informat d \
    -l1-isize 32K -l1-iassoc 4 -l1-ibsize 64 -l1-irepl l \
    -l1-dsize 32K -l1-dassoc 8 -l1-dbsize 64 -l1-drepl l -l1-dfetch d -l1-dwalloc a \
    -l2-usize 512K -l2-uassoc 8 -l2-ubsize 64 -l2-urepl l \
    < $OUTDIR/trace.txt &> $OUTDIR/dinero_results.txt

echo "=== Executing custom Cachesim ==="
./cachesim 1 > $OUTDIR/our_results.txt

echo ""
echo "================ CACHE MISSES COMPARISON ================="
echo "CACHE LEVEL | DINERO IV | CUSTOM CACHESIM"
echo "----------------------------------------------------------"

# Extract L1 Instruction Cache Misses (Column 3 is 'Total')
D_L1I=$(awk '/l1-icache/ {flag=1} flag && /Demand Misses/ {print $3; flag=0}' $OUTDIR/dinero_results.txt)
C_L1I=$(grep "L1I - Hits:" $OUTDIR/our_results.txt | awk -F'[:,]' '{print $4}' | tr -d ' ')
printf "L1I Misses  | %-9s | %-15s\n" "$D_L1I" "$C_L1I"

# Extract L1 Data Cache Misses
D_L1D=$(awk '/l1-dcache/ {flag=1} flag && /Demand Misses/ {print $3; flag=0}' $OUTDIR/dinero_results.txt)
C_L1D=$(grep "L1D - Hits:" $OUTDIR/our_results.txt | awk -F'[:,]' '{print $4}' | tr -d ' ')
printf "L1D Misses  | %-9s | %-15s\n" "$D_L1D" "$C_L1D"

# Extract L2 Unified Cache Misses
D_L2=$(awk '/l2-ucache/ {flag=1} flag && /Demand Misses/ {print $3; flag=0}' $OUTDIR/dinero_results.txt)
C_L2=$(grep "L2  - Hits:" $OUTDIR/our_results.txt | awk -F'[:,]' '{print $4}' | tr -d ' ')
printf "L2 Misses   | %-9s | %-15s\n" "$D_L2" "$C_L2"
echo "=========================================================="