# INF-2200: Cache Simulator

A trace-driven memory hierarchy simulator developed for the INF-2200 course. This project models a CPU cache architecture featuring an L1 Instruction cache, an L1 Data cache, and an L2 Unified cache, implementing LRU replacement, write-back, write-allocate policies, and strict L2 inclusion.

## Prerequisites

To build and run the simulator and its testing suite, you need a standard Linux environment with the following tools installed:
* `gcc` (GNU Compiler Collection)
* `make`
* `bash`

## Project Structure

```text
src/
├── Makefile            # Build automation
├── cpu.c               # CPU simulation, benchmarks, trace generation
├── memory.c            # Cache logic, access handling, eviction policies
├── memory.h            # Cache definitions, data structures, public API
└── tests/
    ├── install_dinero.sh   # Auto-installation script for Dinero IV
    ├── test_math.c         # Independent cache logic validation tests
    └── verify.sh           # Dinero IV cross-validation script

```

## Build Instructions

Navigate to the `src/` directory and use `make` to compile the project:

```bash
make
```

This command will compile the source files and generate the `cachesim` executable.

## Running the Simulator

The simulator can be run using the generated `cachesim` executable. It accepts optional command-line arguments to override the default AMD Zen1 cache configuration.

```bash
./cachesim [benchmark_type] [line_size] [l1d_size] [l1d_assoc] [l2_size] [l2_assoc] [repl_policy] [write_policy]
```

**Benchmark Types:**

* `0`: Naive Matrix Multiplication
* `1`: Block Matrix Multiplication (Cache optimized)
* `3`: Trace Generation (Used internally for Dinero IV validation)

**Replacement policy:**
* `0` : LRU
* `1` : Random

**Write policy:**
* `0` : Write back
* `1` : Write through

*Example (Running the Block Matrix Multiplication with default parameters):*

```bash
./cachesim 1
```

## Testing and Validation

The project includes an automated testing pipeline. The testing suite validates the internal math (spatial locality, associativity conflicts, LRU logic) and cross-validates the overall cache behavior against the industry-standard **Dinero IV** simulator.

To run the entire test suite, simply use:

```bash
make test
```

### What happens during `make test`?

1. **Dinero IV Installation**: The `Makefile` checks if Dinero IV is installed in `tests/dineroIV/`. If not, it automatically executes `install_dinero.sh` to download and compile it.
2. **Logic Validation**: Compiles and runs `test_math.c` to prove the mathematical exactness of the cache mechanisms using independent, hardcoded memory accesses.
3. **Cross-Validation (`make verify`)**:
* Generates a memory trace of the CPU execution.
* Feeds the trace into Dinero IV configured with identical cache parameters.
* Executes the custom `cachesim`.
* Parses and compares the L1I, L1D, and L2 misses side-by-side in a formatted table.



*(Note: You can run the cross-validation independently using `make verify`).*

## Cleaning Up

To remove all compiled object files, generated executables, and temporary text traces produced during testing, run:

```bash
make clean
```